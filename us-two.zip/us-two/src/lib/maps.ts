type P = { name: string; address?: string | null; lat?: number | null; lng?: number | null };
const q = (p: P) => encodeURIComponent(p.address || p.name);
export const googleMapsUrl = (p: P) => p.lat != null && p.lng != null
  ? `https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lng}` : `https://www.google.com/maps/search/?api=1&query=${q(p)}`;
export const naverMapUrl = (p: P) => `https://map.naver.com/p/search/${q(p)}`;
