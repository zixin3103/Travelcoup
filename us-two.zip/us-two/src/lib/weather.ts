// Replaceable adapter: implement WeatherProvider for another API. Open-Meteo needs no key.
export type Forecast = { date: string; max: number; min: number; precipProb: number | null; code: number }[];
export type Weather = { city: string; current: { temp: number; feelsLike: number; code: number }; daily: Forecast; updatedAt: string; rangeDays: number };
export interface WeatherProvider { get(city: string): Promise<Weather> }
// City-level presets only (not place coordinates).
export const CITIES: Record<string, { lat: number; lng: number; tz: string }> = {
  Seoul: { lat: 37.5665, lng: 126.978, tz: "Asia/Seoul" }, Busan: { lat: 35.1796, lng: 129.0756, tz: "Asia/Seoul" } };
export const openMeteo: WeatherProvider = {
  async get(city) {
    const c = CITIES[city]; if (!c) throw new Error("Unsupported city");
    const u = `https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lng}&timezone=${encodeURIComponent(c.tz)}` +
      `&current=temperature_2m,apparent_temperature,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&forecast_days=16`;
    const r = await fetch(u, { next: { revalidate: 1800 } });
    if (!r.ok) throw new Error(`Weather provider error ${r.status}`);
    const j = await r.json();
    return { city, rangeDays: 16, updatedAt: j.current.time,
      current: { temp: j.current.temperature_2m, feelsLike: j.current.apparent_temperature, code: j.current.weather_code },
      daily: j.daily.time.map((d: string, i: number) => ({ date: d, max: j.daily.temperature_2m_max[i], min: j.daily.temperature_2m_min[i],
        precipProb: j.daily.precipitation_probability_max[i], code: j.daily.weather_code[i] })) };
  } };
