export type TripStatus = "upcoming" | "in_progress" | "completed";
/** Today's date (YYYY-MM-DD) in the trip's time zone. */
export function todayIn(tz: string, now = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: tz }).format(now);
}
const dayNum = (d: string) => Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10)) / 86400000;
export function tripProgress(start: string, end: string, tz: string, now = new Date()) {
  const t = dayNum(todayIn(tz, now)), s = dayNum(start), e = dayNum(end);
  if (t < s) return { status: "upcoming" as TripStatus, daysUntil: s - t };
  if (t > e) return { status: "completed" as TripStatus };
  return { status: "in_progress" as TripStatus, day: t - s + 1, total: e - s + 1, remaining: e - t };
}
