import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";
import { tripProgress, todayIn } from "@/lib/trip";
import { openMeteo, CITIES } from "@/lib/weather";

export const dynamic = "force-dynamic";
export default async function Home({ searchParams }: { searchParams: Promise<{ city?: string }> }) {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return <p>Please sign in to see your trips. (Add a /login page using Supabase Auth.)</p>;
  const { data: trip } = await sb.from("trips").select("*").order("start_date").limit(1).maybeSingle();
  if (!trip) return <p className="text-cocoa">No trip yet. Create your first trip to begin.</p>;

  const p = tripProgress(trip.start_date, trip.end_date, trip.time_zone);
  const today = todayIn(trip.time_zone);
  const { data: items } = await sb.from("itinerary_items").select("id,title,plan,booking,start_time,end_time,places(name,city)")
    .eq("trip_id", trip.id).eq("date", today).order("start_time", { nullsFirst: false });
  const sp = await searchParams;
  const city = sp.city && CITIES[sp.city] ? sp.city : trip.destinations.find((d: string) => CITIES[d]) ?? "Seoul";
  const weather = await openMeteo.get(city).then((w) => ({ w }), (e: Error) => ({ err: e.message }));

  return (<div className="space-y-6">
    <section className="rounded-2xl border border-oat bg-white p-5">
      <h1 className="font-serif text-2xl text-cocoa">{trip.name}</h1>
      <p className="text-sm text-taupe">{trip.destinations.join(", ")} · {trip.start_date} to {trip.end_date}</p>
      <p className="mt-3 text-lg">{p.status === "upcoming" ? `${p.daysUntil} days until departure`
        : p.status === "in_progress" ? `Day ${p.day} of ${p.total} · ${p.remaining} days left` : "Trip completed"}</p>
    </section>

    <section className="rounded-2xl border border-oat bg-white p-5">
      <div className="flex gap-2 mb-3">{Object.keys(CITIES).map((c) =>
        <Link key={c} href={`/?city=${c}`} className={`px-3 py-2 rounded-lg text-sm ${c === city ? "bg-cocoa text-cream" : "bg-oat"}`}>{c}</Link>)}</div>
      {"w" in weather && weather.w ? (<>
        <p>{Math.round(weather.w.current.temp)}°C, feels like {Math.round(weather.w.current.feelsLike)}°C</p>
        <ul className="mt-2 text-sm grid grid-cols-2 sm:grid-cols-4 gap-2">{weather.w.daily.slice(0, 4).map((d) =>
          <li key={d.date} className="rounded-lg bg-cream p-2">{d.date}<br />{Math.round(d.min)}–{Math.round(d.max)}°C · {d.precipProb ?? "n/a"}% rain</li>)}</ul>
        <p className="mt-2 text-xs text-taupe">Updated {weather.w.updatedAt}. Forecasts cover {weather.w.rangeDays} days from today; later dates are unavailable.</p>
      </>) : <p className="text-sm text-cocoa">Weather unavailable right now. {"err" in weather ? weather.err : ""}</p>}
    </section>

    <section>
      <h2 className="font-serif text-xl text-cocoa mb-2">Today</h2>
      {items?.length ? <ul className="space-y-2">{items.map((i: any) => (
        <li key={i.id}><Link href={`/itinerary/${i.id}`} className={`block rounded-xl p-3 border ${i.plan === "fixed" ? "border-cocoa bg-oat" : "border-dashed border-taupe bg-white"}`}>
          <span className="text-xs text-taupe">{i.start_time?.slice(0, 5) ?? "Anytime"}{i.end_time ? `–${i.end_time.slice(0, 5)}` : ""} · {i.plan === "fixed" ? "Fixed" : "Flexible"}{i.booking === "confirmed" ? " · Booked" : ""}</span>
          <div>{i.places?.name ?? i.title}</div><div className="text-sm text-taupe">{i.places?.city}</div></Link></li>))}</ul>
        : <p className="text-sm text-taupe">Nothing planned today. Add a plan or pick from your wishlist.</p>}
    </section></div>);
}
