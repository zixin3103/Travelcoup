import "./globals.css";
import Link from "next/link";
export const metadata = { title: "Us Two · Travel Planner" };
const nav = [["/", "Home"], ["/itinerary", "Itinerary"], ["/wishlist", "Wishlist"], ["/map", "Map"], ["/preparation", "Preparation"]];
export default function Root({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body className="font-sans min-h-screen">
    <header className="border-b border-oat bg-cream/90 sticky top-0 z-10">
      <div className="mx-auto max-w-4xl flex items-center gap-4 px-4 py-3">
        <span className="font-serif text-lg text-cocoa">Us Two <span aria-hidden className="text-olive">♡</span></span>
        <nav className="flex gap-1 overflow-x-auto text-sm">{nav.map(([h, l]) =>
          <Link key={h} href={h} className="px-3 py-2 rounded-lg hover:bg-oat whitespace-nowrap min-h-[44px] flex items-center">{l}</Link>)}</nav>
      </div></header>
    <main className="mx-auto max-w-4xl px-4 py-6">{children}</main></body></html>);
}
