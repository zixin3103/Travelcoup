import { describe, it, expect } from "vitest";
import { tripProgress } from "../src/lib/trip";
describe("tripProgress", () => {
  const now = new Date("2026-11-01T00:00:00Z");
  it("upcoming", () => expect(tripProgress("2026-11-10","2026-11-15","Asia/Seoul",now)).toMatchObject({status:"upcoming",daysUntil:9}));
  it("in progress", () => expect(tripProgress("2026-11-01","2026-11-05","Asia/Seoul",now)).toMatchObject({status:"in_progress",day:1,remaining:4}));
  it("completed", () => expect(tripProgress("2026-10-01","2026-10-05","Asia/Seoul",now).status).toBe("completed"));
});
