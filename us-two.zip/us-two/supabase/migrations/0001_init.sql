create extension if not exists pgcrypto;
create type member_role as enum ('owner','editor','viewer');
create type plan_type as enum ('fixed','flexible');
create type booking_status as enum ('not_booked','pending','confirmed','cancelled');

create table profiles(id uuid primary key references auth.users on delete cascade, display_name text, created_at timestamptz default now());
create table trips(id uuid primary key default gen_random_uuid(), name text not null, destinations text[] not null default '{}',
  start_date date not null, end_date date not null, time_zone text not null default 'Asia/Seoul',
  budget numeric, created_by uuid not null references auth.users, created_at timestamptz default now(), check (end_date>=start_date));
create table trip_members(trip_id uuid references trips on delete cascade, user_id uuid references auth.users on delete cascade,
  role member_role not null default 'editor', primary key(trip_id,user_id));
create table trip_invites(id uuid primary key default gen_random_uuid(), trip_id uuid not null references trips on delete cascade,
  token_hash text not null unique, role member_role not null default 'editor', expires_at timestamptz not null, used_at timestamptz);

create table places(id uuid primary key default gen_random_uuid(), trip_id uuid not null references trips on delete cascade,
  name text not null, branch text, country text, city text, category text, address text, lat double precision, lng double precision,
  description text, highlights text, notes text,
  opening_hours jsonb, -- null = unknown; {"mon":{"closed":true}} = confirmed closed
  hours_note text, hours_verified_on date, price numeric, currency text, recommended text, booking_requirements text,
  reservation_url text, website text, social_url text, source_url text, priority int, archived_at timestamptz,
  created_at timestamptz default now());
create index on places(trip_id);

create table itinerary_items(id uuid primary key default gen_random_uuid(), trip_id uuid not null references trips on delete cascade,
  place_id uuid references places on delete restrict, title text, plan plan_type not null default 'flexible',
  booking booking_status not null default 'not_booked', date date not null, start_time time, end_time time,
  duration_min int, notes text, sort_order int default 0, created_at timestamptz default now(),
  check (place_id is not null or title is not null));
create unique index on itinerary_items(place_id,date) where place_id is not null; -- no accidental duplicate scheduling
create index on itinerary_items(trip_id,date);

create table preparation_items(id uuid primary key default gen_random_uuid(), trip_id uuid not null references trips on delete cascade,
  section text not null check (section in ('apps','packing','outfit')), category text, label text not null,
  checked boolean not null default false, sort_order int default 0, data jsonb not null default '{}', created_at timestamptz default now());
create index on preparation_items(trip_id,section);

create table travel_documents(id uuid primary key default gen_random_uuid(), trip_id uuid not null references trips on delete cascade,
  title text not null, category text not null, storage_path text not null, restricted boolean not null default false,
  place_id uuid references places on delete set null, uploaded_by uuid references auth.users, created_at timestamptz default now());
create table document_access(document_id uuid references travel_documents on delete cascade, user_id uuid references auth.users on delete cascade, primary key(document_id,user_id));

-- helpers (security definer avoids RLS recursion)
create function public.trip_role(t uuid) returns member_role language sql stable security definer set search_path=public as
$$ select role from trip_members where trip_id=t and user_id=auth.uid() $$;
create function public.can_edit(t uuid) returns boolean language sql stable security definer set search_path=public as
$$ select coalesce(public.trip_role(t) in ('owner','editor'),false) $$;

alter table profiles enable row level security; alter table trips enable row level security; alter table trip_members enable row level security;
alter table trip_invites enable row level security; alter table places enable row level security; alter table itinerary_items enable row level security;
alter table preparation_items enable row level security; alter table travel_documents enable row level security; alter table document_access enable row level security;

create policy p_self on profiles for all using (id=auth.uid()) with check (id=auth.uid());
create policy trips_sel on trips for select using (trip_role(id) is not null);
create policy trips_ins on trips for insert with check (created_by=auth.uid());
create policy trips_upd on trips for update using (trip_role(id)='owner');
create policy trips_del on trips for delete using (trip_role(id)='owner');
create policy mem_sel on trip_members for select using (trip_role(trip_id) is not null);
create policy mem_all on trip_members for all using (trip_role(trip_id)='owner') with check (trip_role(trip_id)='owner');
create policy inv_owner on trip_invites for all using (trip_role(trip_id)='owner') with check (trip_role(trip_id)='owner');
create policy pl_sel on places for select using (trip_role(trip_id) is not null);
create policy pl_w on places for all using (can_edit(trip_id)) with check (can_edit(trip_id));
create policy it_sel on itinerary_items for select using (trip_role(trip_id) is not null);
create policy it_w on itinerary_items for all using (can_edit(trip_id)) with check (can_edit(trip_id));
create policy pr_sel on preparation_items for select using (trip_role(trip_id) is not null);
create policy pr_w on preparation_items for all using (can_edit(trip_id)) with check (can_edit(trip_id));
create policy doc_sel on travel_documents for select using (trip_role(trip_id)='owner' or
  (trip_role(trip_id) is not null and (not restricted or exists(select 1 from document_access a where a.document_id=id and a.user_id=auth.uid()))));
create policy doc_w on travel_documents for all using (can_edit(trip_id)) with check (can_edit(trip_id));
create policy acc_owner on document_access for all using (exists(select 1 from travel_documents d where d.id=document_id and trip_role(d.trip_id)='owner'))
  with check (exists(select 1 from travel_documents d where d.id=document_id and trip_role(d.trip_id)='owner'));

-- creator becomes owner automatically
create function public.add_owner() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into trip_members values(new.id,new.created_by,'owner'); return new; end $$;
create trigger trg_owner after insert on trips for each row execute function add_owner();

-- private bucket; object path = <trip_id>/<file>
insert into storage.buckets(id,name,public) values('travel-docs','travel-docs',false) on conflict do nothing;
create policy st_sel on storage.objects for select using (bucket_id='travel-docs' and
  exists(select 1 from travel_documents d where d.storage_path=name)); -- reuses document RLS
create policy st_ins on storage.objects for insert with check (bucket_id='travel-docs' and can_edit(((storage.foldername(name))[1])::uuid));
create policy st_del on storage.objects for delete using (bucket_id='travel-docs' and can_edit(((storage.foldername(name))[1])::uuid));
